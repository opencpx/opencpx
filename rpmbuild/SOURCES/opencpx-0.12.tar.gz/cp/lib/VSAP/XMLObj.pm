package VSAP::XMLObj;

use strict;
use vars qw($VERSION @ISA);
use XML::SimpleObject::LibXML;

$VERSION = '0.2';

@ISA = qw(XML::SimpleObject::LibXML);

1;
__END__

