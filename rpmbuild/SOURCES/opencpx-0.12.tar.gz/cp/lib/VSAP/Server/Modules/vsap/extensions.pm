package VSAP::Server::Modules::vsap::extensions;

use 5.008004;
use strict;
use warnings;

use VSAP::Server::Modules::vsap::logger;
use VSAP::Server::Modules::vsap::config;

our $VERSION = '0.01';

our %_ERR = (ERR_PERMISSION_DENIED =>       100,
             ERR_READ_CONF_FAILED =>        101,
             ERR_INVALID_INSTALLER_PATH =>  102,
             ERR_INSTALLER_FAILED =>        103,
             ERR_NOT_AUTHORIZED =>          104,
             ERR_UNKNOWN =>                 110,
);


################################################################################
sub _checkAuth {
  my $username = shift;
  my $users = shift;
  my $serverAdmin = shift;
  my $co = new VSAP::Server::Modules::vsap::config( username => $username );
  my $auth = 0;
  my @users = split( ':', $users );
  
  foreach my $user ( @users ) {
    
    next if ( $user !~ /(server_admin|domain_admin|end_user)/ ); # Skip invalid
    
    if ( ( $user eq 'server_admin' and $serverAdmin ) or
         ( $user eq 'domain_admin' and $co->domain_admin ) or
           $user eq 'end_user' )
    {
      
      $auth = 1;
      last;
      
    }
  
  }

  return $auth;

}



################################################################################
# Possibly, at some point, this could return a list of extensions or such.
sub handler {

  my $vsap = shift;
  my $xmlobj = shift;
  my $dom = shift;
  
  my $rootNode = $dom->createElement( 'vsap' );
  $dom->documentElement->appendChild( $rootNode );
  return;

}



################################################################################
package VSAP::Server::Modules::vsap::extensions::customnav;

sub handler {

  my $vsap = shift;
  my $xmlobj = shift;
  my $dom = shift;
  my $conf = '/home/etc/cp_customnav.conf';
  
  my $urlNode;
  my $paramNode;

  my $rootNode = $dom->createElement( 'vsap' );
  $rootNode->setAttribute( 'type' => 'customnav' );
  
  my $urlKey = '';
  my $execAuth = 0;

  if ( -f $conf ) {
    
    open ( CONF, "<$conf" ) or do {
            
            VSAP::Server::Modules::vsap::logger::log_message("customnav: error opening $conf");
            $dom->documentElement->appendChild( $rootNode );
            return;
            
          };
    
    while ( <CONF> ) {
      
      chomp;
      
      next if ( /^#/ );
      
      if ( /^\[nav_label=.+\]/ ) {
        my $tag;
        my $navLabel;

        ( $tag, $navLabel ) = split( '=' );
        $navLabel =~ s/\].*$//;
        $rootNode->appendTextChild( 'sideNavLabel' => $navLabel );
        
        next;
      }

      if ( /^\[url=.+\]/ ) {

        my $tag;
        ( $tag, $urlKey ) = split( '=' );
        $urlKey =~ s/\].*$//;
        
        if ( $urlNode and $execAuth ) {

          $rootNode->appendChild( $urlNode );
          $urlNode = '';
          $execAuth = 0;

        }

        $urlNode = $dom->createElement( 'url' );
        $urlNode->appendTextChild( 'url_key' => $urlKey );
        
      }
      elsif ( /^(label|location)/ ) {
        
        my ( $tag, $value ) = split( '=' );
        if ( $urlNode ) {

          $urlNode->appendTextChild( $tag => $value );

        }
        else {

          VSAP::Server::Modules::vsap::logger::log_message( "customnav: 'label' or 'location' encountered before '[url]' indicator in $conf" );

        }
        
      }
      elsif ( /^user=/ ) {
        
        if ( $urlNode ) {
          my $users;
          my @users;
          my $tag;
          
          ( $tag, $users ) = split( '=' );
          
          if ( $users ) {
            
            $execAuth = VSAP::Server::Modules::vsap::extensions::_checkAuth( $vsap->{username}, $users, $vsap->{server_admin} );
          
          }
  
        }
        else {

          $vsap->error($_ERR{ERR_READ_CONF_FAILED} => "Error: 'user' encountered before '[url]' indicator in $conf");
          VSAP::Server::Modules::vsap::logger::log_error( "customnav: 'user' encountered before '[url]' indicator in $conf" );
          return;

        }
        
      }
      elsif ( /^parameter/ ) {
        
        my ( $tag, $param ) = split( '=' );
        my ( $name, $value ) = split( '::', $param );
        if ( $urlNode ) {
          
          $paramNode = $dom->createElement( 'parameter' );
          $paramNode->setAttribute( 'name', $name );
          $paramNode->setAttribute( 'value', $value );
          $urlNode->appendChild( $paramNode );
          
        }
        else {

          VSAP::Server::Modules::vsap::logger::log_message( "customnav: 'parameter' encountered before '[url]' indicator in $conf" );

        }
        
      }
      
    }
    
    close ( CONF );

    if ( $urlNode and $execAuth ) {

      $rootNode->appendChild( $urlNode );
      $urlNode = '';

    }

  }
  else {
    
    VSAP::Server::Modules::vsap::logger::log_message( "customnav: missing $conf" );
    
  }
  
  $dom->documentElement->appendChild( $rootNode );
  return;

}



################################################################################
package VSAP::Server::Modules::vsap::extensions::oneclick_apps;

sub handler {

  my $vsap = shift;
  my $xmlobj = shift;
  my $dom = shift;
  my $conf = '/home/etc/addon_applications.conf';
  
  my $appNode;
  
  my $rootNode = $dom->createElement( 'vsap' );
  $rootNode->setAttribute( 'type' => 'oneclick_app' );
  
  my $co = new VSAP::Server::Modules::vsap::config( username => $vsap->{username} );
        
  if ( -f $conf ) {
    
    open ( CONF, "<$conf" ) or do {
            
            $vsap->error($_ERR{ERR_READ_CONF_FAILED} => "Error: error opening $conf");
            VSAP::Server::Modules::vsap::logger::log_error("oneclick_install: error opening $conf");
            return;
            
          };
    
    my $appKey;
    my $execAuth = 0;

    while ( <CONF> ) {
      
      chomp;
      
      next if ( /^#/ );
      
      if ( /^\[application=.+\]/ ) {
        
        my $tag;
        ( $tag, $appKey ) = split( '=' );
        $appKey =~ s/\].*$//;
        
        if ( $appNode ) {

          $rootNode->appendChild( $appNode );
          $appNode = '';

        }

        $appNode = $dom->createElement( 'app' );
        
      }
      elsif ( /^icon=/ ) {
        
        my ( $tag, $value ) = split( '=' );
        if ( $appNode ) {

          $appNode->appendTextChild( $tag => $value );

        }
        else {

          $vsap->error($_ERR{ERR_READ_CONF_FAILED} => "Error: 'icon' encountered before '[application]' indicator in $conf");
          VSAP::Server::Modules::vsap::logger::log_error( "oneclick_apps: 'icon' encountered before '[application]' indicator in $conf" );
          return;

        }
        
      }
      elsif ( /^icon_inactive=/ ) {
        
        my ( $tag, $value ) = split( '=' );
        if ( $appNode ) {

          $appNode->appendTextChild( $tag => $value );

        }
        else {

          $vsap->error($_ERR{ERR_READ_CONF_FAILED} => "Error: 'icon_inactive' encountered before '[application]' indicator in $conf");
          VSAP::Server::Modules::vsap::logger::log_error( "oneclick_apps: 'icon_inactive' encountered before '[application]' indicator in $conf" );
          return;

        }
        
      }
      elsif ( /^checkfile/ ) {
        
        my ( $tag, $checkFile ) = split( '=' );
        
        my $checkFileExists = ( -e "/home/$vsap->{username}/$checkFile" ) ? 'true' : 'false';
          
        if ( $appNode ) {
          
          $appNode->appendTextChild( $tag => $checkFileExists );
          
        }
        else {
          
          $vsap->error($_ERR{ERR_READ_CONF_FAILED} => "Error: 'checkfile' encountered before '[application]' indicator in $conf");
          VSAP::Server::Modules::vsap::logger::log_error( "oneclick_apps: 'checkfile' encountered before '[application]' indicator in $conf" );
          return;
        }
       
      }
      elsif ( /^linktext/ ) {
        
        my ( $tag, $linkText ) = split( '=' );
        
        if ( $appNode ) {
          
          $appNode->appendTextChild( $tag => $linkText );
          
        }
        else {
          
          $vsap->error($_ERR{ERR_READ_CONF_FAILED} => "Error: 'linktext' encountered before '[application]' indicator in $conf");
          VSAP::Server::Modules::vsap::logger::log_error( "oneclick_apps: 'linktext' encountered before '[application]' indicator in $conf" );
          return;
        }
       
      }
      elsif ( /^user=/ ) {
        
        if ( $appNode ) {
          my $users;
          my @users;
          my $tag;
          
          ( $tag, $users ) = split( '=' );
          
          if ( $users ) {
            
            $execAuth = VSAP::Server::Modules::vsap::extensions::_checkAuth( $vsap->{username}, $users, $vsap->{server_admin} );
          
          }
  
        }
        else {

          $vsap->error($_ERR{ERR_READ_CONF_FAILED} => "Error: 'user' encountered before '[application]' indicator in $conf");
          VSAP::Server::Modules::vsap::logger::log_error( "oneclick_apps: 'user' encountered before '[application]' indicator in $conf" );
          return;

        }
        
      }

      if ( $appNode and $execAuth ) {
        $appNode->appendTextChild( 'app_key' => $appKey );
        $execAuth = 0;
      }
      else {
        $execAuth = 0;
      }
     
    }
    
    close ( CONF );
    
    if ( $appNode ) {
      
      $rootNode->appendChild( $appNode );
      $appNode = '';
      
    }
    
  }
  else {
    
    $vsap->error($_ERR{ERR_READ_CONF_FAILED} => "Error: missing $conf");
    VSAP::Server::Modules::vsap::logger::log_message( "oneclick_apps: missing $conf" );
    
  }
  
  $dom->documentElement->appendChild( $rootNode );
  return;

}



################################################################################
package VSAP::Server::Modules::vsap::extensions::oneclick_install;

sub handler {

  use IPC::Open3;
  use Symbol qw(gensym);
  use IO::File;

  my $vsap = shift;
  my $xmlobj = shift;
  my $dom = shift;
  my $conf = '/home/etc/addon_applications.conf';
  my $installBase = '/home';
  my $script;
  my $execAuth = 0;
  my $status = '';
  my $scriptExit = -1;
  
  my $appKey = $xmlobj->child('app_key')->value;
  my $domain = $xmlobj->child('domain')->value;
  
  my $rootNode = $dom->createElement( 'vsap' );
  $rootNode->setAttribute( 'type' => 'oneclick_install' );

  if ( -f $conf ) {
    
    open ( CONF, "<$conf" ) or do {
            
            $vsap->error($_ERR{ERR_READ_CONF_FAILED} => "Error: error opening $conf");
            VSAP::Server::Modules::vsap::logger::log_error("oneclick_install: error opening $conf");
            $dom->documentElement->appendChild( $rootNode );
            return;
            
          };
    
    while ( <CONF> ) {
      
      chomp;
      
      next if ( /^#/ );
      
      next unless ( /\[application=$appKey\]/ );
      
      my $line = '';
      
      until ( $line =~ /\[application=/ or eof(CONF) ) {
        $line = <CONF>;
        chomp $line;
        
        my $tag;
        
        if ( $line =~ /^script=/ ) {
          ( $tag, $script ) = split( '=', $line );
          
          # keep the script within the base path.
          if ( $script =~ /(~|\.{2}\/?)/ ) {
            # Invalid path.
            $vsap->error($_ERR{ERR_INVALID_INSTALLER_PATH} => "Error: invalid script path $script");
            VSAP::Server::Modules::vsap::logger::log_error( "Error: invalid script path $script" );
            return;
          }
        }

        if ( $line =~ /^user=/ ) {
          
          my $users;
          my @users;
          
          ( $tag, $users ) = split( '=', $line );
          
          if ( $users ) {
            
            $execAuth = VSAP::Server::Modules::vsap::extensions::_checkAuth( $vsap->{username}, $users, $vsap->{server_admin} );
          
          }
  
          if ( ! $execAuth ) {
             $vsap->error($_ERR{'ERR_NOT_AUTHORIZED'} => "Unauthorized user");
             VSAP::Server::Modules::vsap::logger::log_error("Unauthorized user");
             return; 
          }
      
        }
        
      }
      
    }
    
    close ( CONF );

  }
  else {
    
    $vsap->error($_ERR{ERR_READ_CONF_FAILED} => "Error: missing $conf");
    VSAP::Server::Modules::vsap::logger::log_error( "oneclick_install: missing $conf" );
    return;

  }

  my $scriptPath = $installBase . $script;
  my $stderr;
  my $stdout;
  my $stdoutNode;
  my $stderrNode;
  
  if ( -e $scriptPath ) {
  
    REWT: {
      local $> = $) = 0; ### TEMP ROOT
      local $> = $vsap->{uid};
      local $) = $vsap->{gid};
      
      if ( ! -x $scriptPath ) {
         $vsap->error($_ERR{'ERR_PERMISSION_DENIED'} => "Permission denied");
         VSAP::Server::Modules::vsap::logger::log_error("Permission denied");
         return; 
      }
      
      my $pid;
      my $exit; 

      local *CATCHERR = IO::File->new_tmpfile;

      $pid = open3(gensym, \*CATCHOUT, ">&CATCHERR", $scriptPath, "user=$vsap->{username}", "domain=$domain");

      while( <CATCHOUT> ) { $stdout .= $_ };

      waitpid($pid, 0);

      $exit = $? >> 8;

      seek CATCHERR, 0, 0;
      while( <CATCHERR> ) { $stderr .= $_ };
      
      if ( $stdout ) {

        $stdoutNode = $dom->createElement( 'stdoutNode' );
        my $stdoutComment = $dom->createTextNode( $stdout);
        $stdoutNode->addChild( $stdoutComment );

      }

      if ( $stderr ) {

        $stderrNode = $dom->createElement( 'stderrNode' );
        my $stderrComment = $dom->createTextNode( $stderr);
        $stderrNode->addChild( $stderrComment );

      }

      if ( $exit != 0 ) {
        $vsap->error( $_ERR{'ERR_INSTALLER_FAILED'} => "$script failed (exitcode $exit)" );
        $vsap->error( USER_CUSTOM => $stderr ) if $stderr;
        VSAP::Server::Modules::vsap::logger::log_error( "$script failed (exitcode $exit)" );
        
        if ( $stderr ) {
          VSAP::Server::Modules::vsap::logger::log_error(" $scriptPath reports: $stderr" );
        }
        
        return;
      }
      
      $scriptExit = $exit;
      $status = 'ok' if ( $scriptExit == 0 );
    }
  
  
  }
  else {
    
    $vsap->error($_ERR{'ERR_INVALID_INSTALLER_PATH'} => "cannot find installation script: $script");
    VSAP::Server::Modules::vsap::logger::log_error( "oneclick_install: cannot find installation script: $script" );
    return;

  }
      

  $rootNode->appendChild( $stdoutNode ) if ( $stdout and $stdoutNode );

  $rootNode->appendTextChild( status => $status ) if ( $status );
  $rootNode->appendTextChild( exit => $scriptExit );

  $dom->documentElement->appendChild( $rootNode );
  return;

}

1;
__END__

=head1 NAME

VSAP::Server::Modules::vsap::extensions - VSAP module for reading and display custom globalnav element menu items from file.

=head1 SYNOPSIS

  use VSAP::Server::Modules::vsap::extensions;

=head1 DESCRIPTION

Package B<VSAP::Server::Modules::vsap::extensions::customnav> is used for 
retrieving custom menu items from file and displaying in the 'globalnav' 
area.

Example:

  <vsap type="extensions:customnav"/>

Returns:

  <vsap type="customnav">
    <url>
      <label>Link Label</label>
      <location>http://www.some.com</location>
      <parameter name="user" value="username"/>
      <parameter name="key" value="keyvalue"/>
    </url>
  </vsap>

All "parameter" elements are optional.

=head1 SEE ALSO

vsap(1)

=head1 AUTHOR

Blake Anderson

=head1 COPYRIGHT AND LICENSE

Copyright (C) 2012 by MYNAMESERVER, LLC

No part of this module may be duplicated in any form without written
consent of the copyright holder.

=cut
